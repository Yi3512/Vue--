<template>
  <div>
    <head-fn></head-fn>
    <form-fn></form-fn>
    <bot-tom></bot-tom>
  </div>
</template>

<script>
import BotTom from "./components/BotTom.vue";
import FormFn from "./components/FormFn.vue";
import HeadFn from "./components/HeadFn.vue";

export default {
  components: { BotTom, FormFn, HeadFn },
  data() {
    return {
      list: [
        {
          id: 1,
          bookname: "",
          author: "",
          publisher: "",
        },
      ],
    };
  },
};
</script>

<style>
</style>